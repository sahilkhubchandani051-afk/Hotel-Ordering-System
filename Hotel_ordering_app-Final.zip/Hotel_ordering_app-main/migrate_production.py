import os
import sys
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Add parent directory to path to find app
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

try:
    import psycopg2
except ImportError:
    psycopg2 = None

from app.main import get_db_connection

def run_migration():
    logger.info("STARTING PRODUCTION MIGRATION")
    
    conn_obj = get_db_connection()
    
    # Determine connection type
    conn = None
    is_postgres = False
    
    # Check for our custom wrapper first (it has a 'conn' attribute)
    if hasattr(conn_obj, 'conn'):
        conn = conn_obj.conn
        is_postgres = True
        logger.info("Detected PostgreSQL Connection")
    elif hasattr(conn_obj, 'cursor'):
        # Standard sqlite3 connection
        conn = conn_obj
        logger.info("Detected SQLite Connection")
    else:
        logger.error(f"Unknown connection object type: {type(conn_obj)}")
        return

    cursor = conn.cursor()
    
    try:
        # ==============================================================================
        # 1. CORE TABLE CHECKS (Products, Customers)
        # ==============================================================================
        logger.info("[1/6] Verifying Core Tables...")
        
        # Check 'products' table columns (Bilingual & Favorites)
        if is_postgres:
            cursor.execute("SELECT column_name FROM information_schema.columns WHERE table_name = 'products'")
            columns = [row[0] for row in cursor.fetchall()]
        else:
            cursor.execute("PRAGMA table_info(products)")
            columns = [row[1] for row in cursor.fetchall()]
            
        # Add missing columns to products
        alter_statements = []
        if 'name_marathi' not in columns:
            alter_statements.append("ALTER TABLE products ADD COLUMN name_marathi TEXT")
        if 'image_url' not in columns:
            alter_statements.append("ALTER TABLE products ADD COLUMN image_url TEXT")
        if 'created_at' not in columns:
            if is_postgres:
                alter_statements.append("ALTER TABLE products ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
            else:
                alter_statements.append("ALTER TABLE products ADD COLUMN created_at TEXT")
        if 'favorite_price' not in columns:
             alter_statements.append("ALTER TABLE products ADD COLUMN favorite_price REAL") # REAL works for both
        
        for sql in alter_statements:
            logger.info(f"Applying: {sql}")
            cursor.execute(sql)

        # Check 'customers' table columns (Favorites)
        if is_postgres:
            cursor.execute("SELECT column_name FROM information_schema.columns WHERE table_name = 'customers'")
            cust_columns = [row[0] for row in cursor.fetchall()]
        else:
            cursor.execute("PRAGMA table_info(customers)")
            cust_columns = [row[1] for row in cursor.fetchall()]
            
        if 'is_favorite' not in cust_columns:
            logger.info("Adding is_favorite to customers")
            cursor.execute("ALTER TABLE customers ADD COLUMN is_favorite BOOLEAN DEFAULT FALSE")

        # ==============================================================================
        # 2. INVENTORY SYSTEM (V2 Schema)
        # ==============================================================================
        logger.info("[2/6] Applying Inventory Schema V2...")
        
        # We define schema inline to control dialect differences
        
        # Inventory Locations
        if is_postgres:
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS inventory_locations (
                    id SERIAL PRIMARY KEY,
                    name VARCHAR(255) NOT NULL UNIQUE
                );
            """)
            # Seed Locations (Postgres)
            cursor.execute("INSERT INTO inventory_locations (id, name) VALUES (1, 'GODOWN') ON CONFLICT (name) DO NOTHING")
            cursor.execute("INSERT INTO inventory_locations (id, name) VALUES (2, 'SHOP') ON CONFLICT (name) DO NOTHING")
        else:
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS inventory_locations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE
                );
            """)
            # Seed Locations (SQLite)
            cursor.execute("INSERT OR IGNORE INTO inventory_locations (id, name) VALUES (1, 'GODOWN')")
            cursor.execute("INSERT OR IGNORE INTO inventory_locations (id, name) VALUES (2, 'SHOP')")

        # Product Settings
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS product_inventory_settings (
                product_id INTEGER PRIMARY KEY,
                default_location_id INTEGER DEFAULT 1,
                FOREIGN KEY (product_id) REFERENCES products(id),
                FOREIGN KEY (default_location_id) REFERENCES inventory_locations(id)
            );
        """)

        # Inventory Ledger
        if is_postgres:
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS inventory_ledger (
                    id SERIAL PRIMARY KEY,
                    product_id INTEGER NOT NULL,
                    location_id INTEGER NOT NULL,
                    transaction_type VARCHAR(50) NOT NULL,
                    qty_change DECIMAL(10,2) NOT NULL,
                    qty_in DECIMAL(10,2) DEFAULT 0,
                    qty_out DECIMAL(10,2) DEFAULT 0,
                    running_balance DECIMAL(10,2) DEFAULT 0,
                    batch_id VARCHAR(50),
                    reference_type VARCHAR(50),
                    reference_id VARCHAR(50),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    created_by VARCHAR(50),
                    FOREIGN KEY (product_id) REFERENCES products(id),
                    FOREIGN KEY (location_id) REFERENCES inventory_locations(id)
                );
            """)
            # Indexes
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_ledger_prod_loc ON inventory_ledger(product_id, location_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_ledger_batch ON inventory_ledger(batch_id)")
            
            # View (Drop if exists to ensure definition update)
            cursor.execute("DROP VIEW IF EXISTS view_inventory_summary")
            cursor.execute("""
                CREATE VIEW view_inventory_summary AS
                SELECT 
                    l.product_id,
                    p.name as product_name,
                    l.location_id,
                    loc.name as location_name,
                    SUM(l.qty_change) as current_stock
                FROM inventory_ledger l
                JOIN products p ON l.product_id = p.id
                JOIN inventory_locations loc ON l.location_id = loc.id
                GROUP BY l.product_id, p.name, l.location_id, loc.name;
            """)
            
        else:
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS inventory_ledger (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    product_id INTEGER NOT NULL,
                    location_id INTEGER NOT NULL,
                    transaction_type VARCHAR(50) NOT NULL,
                    qty_change DECIMAL(10,2) NOT NULL,
                    qty_in DECIMAL(10,2) DEFAULT 0,
                    qty_out DECIMAL(10,2) DEFAULT 0,
                    running_balance DECIMAL(10,2) DEFAULT 0,
                    batch_id VARCHAR(50),
                    reference_type VARCHAR(50),
                    reference_id VARCHAR(50),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    created_by VARCHAR(50),
                    FOREIGN KEY (product_id) REFERENCES products(id),
                    FOREIGN KEY (location_id) REFERENCES inventory_locations(id)
                );
            """)
            # SQLite View
            cursor.execute("DROP VIEW IF EXISTS view_inventory_summary")
            cursor.execute("""
                CREATE VIEW view_inventory_summary AS
                SELECT 
                    l.product_id,
                    p.name as product_name,
                    l.location_id,
                    loc.name as location_name,
                    SUM(l.qty_change) as current_stock
                FROM inventory_ledger l
                JOIN products p ON l.product_id = p.id
                JOIN inventory_locations loc ON l.location_id = loc.id
                GROUP BY l.product_id, l.location_id;
            """)

        # ==============================================================================
        # 3. DELIVERY TRACKING (Purchase Orders & Categories)
        # ==============================================================================
        logger.info("[3/6] Verifying Delivery Tracking Schema...")
        
        # Check customer_categories
        if is_postgres:
            cursor.execute("SELECT column_name FROM information_schema.columns WHERE table_name = 'customer_categories'")
            cat_columns = [row[0] for row in cursor.fetchall()]
        else:
            cursor.execute("PRAGMA table_info(customer_categories)")
            cat_columns = [row[1] for row in cursor.fetchall()]
            
        if 'delivery_days' not in cat_columns:
            logger.info("Adding delivery_days to customer_categories")
            cursor.execute("ALTER TABLE customer_categories ADD COLUMN delivery_days TEXT")

        # Check purchase_orders
        if is_postgres:
            cursor.execute("SELECT column_name FROM information_schema.columns WHERE table_name = 'purchase_orders'")
            po_columns = [row[0] for row in cursor.fetchall()]
        else:
            cursor.execute("PRAGMA table_info(purchase_orders)")
            po_columns = [row[1] for row in cursor.fetchall()]

        po_cols_to_add = [
            ("expected_delivery_date", "DATE"),
            ("delivery_stage", "VARCHAR(50) DEFAULT 'ORDER_PLACED'"),
            ("delivery_status", "VARCHAR DEFAULT 'OPEN'"),
            ("tracking_status", "VARCHAR DEFAULT 'PO_CREATED'"),
            ("order_placed_at", "TIMESTAMP"),
            ("packaged_at", "TIMESTAMP"),
            ("shipped_at", "TIMESTAMP"),
            ("out_for_delivery_at", "TIMESTAMP"),
            ("delivered_at", "TIMESTAMP"),
            ("amount_received", "REAL DEFAULT 0"), # From Direct Sales / Payment
            ("invoice_receipt", "REAL DEFAULT 0"), # For Invoice Amount (Final)
            ("invoice_source", "TEXT DEFAULT 'PR'") # From Direct Sales
        ]

        for col_name, col_type in po_cols_to_add:
            if col_name not in po_columns:
                logger.info(f"Adding {col_name} to purchase_orders")
                cursor.execute(f"ALTER TABLE purchase_orders ADD COLUMN {col_name} {col_type}")

        # ==============================================================================
        # 4. DIRECT SALES MIGRATION (Legacy Table Cleanup if needed)
        # ==============================================================================
        logger.info("[4/6] Checking Direct Sales Schema...")
        # (Handled by column additions above: amount_received, invoice_source)

        # ==============================================================================
        # 5. REORDER LEVEL COLUMNS (Products)
        # ==============================================================================
        logger.info("[5/6] Checking Reorder Levels...")
        if 'reorder_level_shop' not in columns:
             cursor.execute("ALTER TABLE products ADD COLUMN reorder_level_shop INTEGER DEFAULT 5")
        if 'reorder_level_godown' not in columns:
             cursor.execute("ALTER TABLE products ADD COLUMN reorder_level_godown INTEGER DEFAULT 10")

        # ==============================================================================
        # 6. COMMIT
        # ==============================================================================
        conn.commit()
        logger.info("PRODUCTION MIGRATION COMPLETED SUCCESSFULLY")

    except Exception as e:
        logger.error(f"MIGRATION FAILED: {e}")
        try:
            conn.rollback()
        except:
            pass
        raise e
    finally:
        try:
            conn.close()
        except:
            pass

if __name__ == "__main__":
    run_migration()
